<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<div class="row">
    <div class="col-6 text-center">
        <form action="<?php echo e(route('importer.store'), false); ?>" method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field(), false); ?>

            <div class="input-group">
                <input required type="file" name="html_file" class="form-control" id="html_file"
                       aria-describedby="inputGroupFileAddon04" aria-label="Upload">
                <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon04">upload</button>
            </div>
        </form>
    </div>
    <div class="col-6 text-center">
        <div class="bg-info">
            previously completed imports
        </div>
        <table class="w-100 bg-light">
            <tr>
                <th class="border">id</th>
                <th class="border">type</th>
                <th class="border">entries_processed</th>
                <th class="border">entries_created</th>
                <th class="border">run_at</th>
            </tr>
            <?php
                $logs = DB::table('importer_log')->get();
            ?>

            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <tr>
                    <td class="border"><?php echo e($log->id, false); ?></td>
                    <td class="border"><?php echo e($log->type, false); ?></td>
                    <td class="border"><?php echo e($log->entries_processed, false); ?></td>
                    <td class="border"><?php echo e($log->entries_created, false); ?></td>
                    <td class="border"><?php echo e($log->run_at, false); ?></td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\CRM\Modules/Importer\Resources/views/index.blade.php ENDPATH**/ ?>