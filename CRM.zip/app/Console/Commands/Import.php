<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Modules\WorkOrder\Models\WorkOrder;
use Modules\Importer\Repositories\ImporterRepository;
use Modules\Importer\Services\ParserService;

class Import extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'import:html {path}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command to import html file from server to database';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }



    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $path = $this->argument('path');

        $tableIDs = [
            'ctl00_ctl00_ContentPlaceHolderMain_MainContent_TicketLists_OpenTickets_ctl00',
            'ctl00_ctl00_ContentPlaceHolderMain_MainContent_TicketLists_PaperworkTickets_ctl00',
            'ctl00_ctl00_ContentPlaceHolderMain_MainContent_TicketLists_AllTickets_ctl00',
        ];

        $parserService = new parserService($path, $tableIDs);
        $data = $parserService->parser(); // convert html file to array

        $ImportRepository = new ImporterRepository(); // instantiate importer

        $ImportRepository->generateCSV($data);
        $ImportRepository->insertLog($data,'artisan command');
        $ImportRepository->store($data);

    }
}
