<?php

namespace App\Http\Requests;

class SimpleRequest extends Request
{
    public function getRules()
    {
        // no implementation needed here
    }
}
