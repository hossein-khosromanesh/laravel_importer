<?php

namespace App\Modules\CustomerSettings\Http\Requests;

use App\Http\Requests\Request;

class CustomerSettingsRequest extends Request
{
}
