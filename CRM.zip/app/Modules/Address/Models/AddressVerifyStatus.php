<?php

namespace App\Modules\Address\Models;

class AddressVerifyStatus
{
    const NOT_VERIFIED = 0;
    const VERIFIED = 1;
    const VERIFY_ERROR = 2;
}
