<?php

namespace App\Modules\Person\Services;

class CompanyComplexValidatorService extends PersonComplexValidatorService
{
}
