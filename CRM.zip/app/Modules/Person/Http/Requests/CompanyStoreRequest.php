<?php

namespace App\Modules\Person\Http\Requests;

class CompanyStoreRequest extends CompanyRequest
{
    protected $action = 'store';
}
