<?php

namespace App\Modules\Person\Http\Requests;

class PersonUpdateRequest extends PersonRequest
{
    protected $action = 'update';
}
