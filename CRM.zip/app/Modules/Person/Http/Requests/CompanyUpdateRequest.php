<?php

namespace App\Modules\Person\Http\Requests;

class CompanyUpdateRequest extends CompanyRequest
{
    protected $action = 'update';
}
